/** @format
 *
 * Fuego By Painfuego
 * Version: 6.0.0-beta
 * © 2024 The Extremez
 */

module.exports = {

  //commands/information/help
  help: {
    arrow: "<:reddot:1261130302000992371>",
    no: "<:reddot:1261130302000992371>",
    point: "<:reddot:1261130302000992371>",
    home: "<:eg_home:1259062957170626613>",
    music: "<:nmusic:1259389298810159156>",
    config: "<:eg_wrench:1259063202881208321>",
    filter: "<:eg_fire:1259063276063559680>",
    information: "<:nquestion:1259063361602064394>",
    all: "<:ndevelopers:1259063434654515242>",
  },

  //commands/information/info
  info: {
    ver: "<:cog:1259063595942150164>",
    web: "<:web:1259064107781455903>",
    partner: "<:partner:1259064200819376139>",
    verified: "<:verified:1259064290250461188>",
    nodejs: "<:nodejs:1259064372127338548>",
    djs: "<:discordjs:1259064473608654851>",
    link: "<:link:1259064548095168554>",
    cog: "<:cog:1259063595942150164>",
    dev: "<:developer:1259062217282945075>",
    admin: "<:admin:1259062418710073365>",
    king: "<:owner:1259064731864399874>",
    no: "<:black_wrong:1185819723947069492>",
    dir: "<:dir:1259066169701437492>",
    lines: "<:line:1259066274399653889>",
  },

  //commands/information/invite
  invite: {
    bell: "<:eg_notification:1259057639753646080>",
  },

  //commands/information/notice
  notice: {
    no: "<:nwrong:1259057991429390377>",
    yes: "<:tick_icon:1259061910473670730>",
    bug: "<:bug:1259066478309933057>",
  },

  //commands/information/ping
  ping: {
    link: "<:link:1259064548095168554>",
    cool: "<:uptime:1259057811028049940>",
    message: "<:message:1259388525233569863>",
    data: "<:dir:1259066169701437492>",
    node: "<:connect:1259446163556536450>",
  },

  //commands/information/report
  report: {
    bell: "<:eg_notification:1259057639753646080>",
    bug: "<:bug:1259066478309933057>",
    danger: "<:danger:1259059064801984616>",
    no: "<:nwrong:1259057991429390377>",
  },

  //commands/information/stats
  stats: {
    cool: "<:uptime:1259057811028049940>",
    no: "<:nwrong:1259057991429390377>",
  },

  //commands/information/support
  support: {
    support: "<:supportteam:1259066598229147702>",
  },

  //commands/information/vote
  vote: {
    vote: "<:vote:1259066679040802846>",
  },

  /////////////////////////////////////////////////////

  //commands/music/autoplay
  autoplay: {
    autoplay: "<:autoplay:1259066787031552032>",
    bell: "<:eg_notification:1259057639753646080>",
    cool: "<:uptime:1259057811028049940>",
    no: "<:nwrong:1259057991429390377>",
    off: "<:ndisable:1259058170656067585>",
    on: "<:nenable:1259058313417461823>",
  },

  //commands/music/clear
  clear: {
    bell: "<:eg_notification:1259057639753646080>",
    cog: "<:nsetting:1259061754219204618>",
    list: "<:queue:1259066946515898428>",
    yes: "<:tick_icon:1259061910473670730>",
  },

  //commands/music/grab
  grab: {
    yes: "<:tick_icon:1259061910473670730>",
    no: "<:nwrong:1259057991429390377>",
    cool: "<:uptime:1259057811028049940>",
    user: "<:users:1259062697685684254>",
  },

  //commands/music/join
  join: {
    bell: "<:eg_notification:1259057639753646080>",
    cool: "<:uptime:1259057811028049940>",
    no: "<:nwrong:1259057991429390377>",
    on: "<:nenable:1259058313417461823>",
    warn: "<:warn:1259061550933606455>",
  },

  //commands/music/leave
  leave: {
    cool: "<:uptime:1259057811028049940>",
    off: "<:ndisable:1259058170656067585>",
  },

  rejoin: {
    cool: "<:uptime:1259057811028049940>",
    on: "<:nenable:1259058313417461823>",
  },

  //commands/music/loop
  loop: {
    loop: "<:loop:1259067180549410896>",
    bell: "<:eg_notification:1259057639753646080>",
    cool: "<:uptime:1259057811028049940>",
    on: "<:nenable:1259058313417461823>",
    off: "<:ndisable:1259058170656067585>",
    no: "<:black_wrong:1185819723947069492>",
    queue: "<:queue:1259066946515898428>",
    track: "<:nmusic:1259389298810159156>",
  },

  //commands/music/nowPlaying
  nowplaying: {},

  //commands/music/pause
  pause: {
    yes: "<:tick_icon:1259061910473670730>",
    no: "<:nwrong:1259057991429390377>",
  },

  //commands/music/play
  play: {
    bell: "<:reddot:1261130302000992371>",
    warn: "<:reddot:1261130302000992371>",
    yes: "<:tick_icon:1259061910473670730>",
    no: "<:nwrong:1259057991429390377>",
    search: "<:search:1259067310811906129>",
  },

  //commands/music/previous
  previous: {
    yes: "<:tick_icon:1259061910473670730>",
    no: "<:nwrong:1259057991429390377>",
  },

  //commands/music/queue
  queue: {
    cool: "<:uptime:1259057811028049940>",
  },

  //commands/music/radio
  radio: {
    cool: "<:uptime:1259057811028049940>",
    no: "<:nwrong:1259057991429390377>",
    radio: "<:radio:1259388822446280745>",
    support: "<:support:1189089913031897118>",
    warn: "<:warn:1259061550933606455>",
    yes: "<:tick_icon:1259061910473670730>",
  },

  //commands/music/remove
  remove: {
    yes: "<:tick_icon:1259061910473670730>",
    no: "<:nwrong:1259057991429390377>",
  },

  //commands/music/resume
  resume: {
    yes: "<:tick_icon:1259061910473670730>",
    no: "<:nwrong:1259057991429390377>",
  },

  //commands/music/search
  search: {
    yes: "<:tick_icon:1259061910473670730>",
    warn: "<:warn:1259061550933606455>",
    no: "<:nwrong:1259057991429390377>",
    youtube: "<:youtube:1259067430093721693>",
    soundcloud: "<:soundcloud:1259387828777783367>",
    spotify: "<:spotify:1259387939025191003>",
    search: "<:search:1259067310811906129>",
    track: "<:nmusic:1259389298810159156>",
  },

  //commands/music/seek
  seek: {
    bell: "<:eg_notification:1259057639753646080>",
    yes: "<:tick_icon:1259061910473670730>",
    no: "<:nwrong:1259057991429390377>",
  },

  //commands/music/shuffle
  shuffle: {
    yes: "<:tick_icon:1259061910473670730>",
  },

  similar: {
    yes: "<:tick_icon:1259061910473670730>",
    warn: "<:warn:1259061550933606455>",
    no: "<:nwrong:1259057991429390377>",
    youtube: "<:youtube:1259067430093721693>",
    soundcloud: "<:soundcloud:1259387828777783367>",
    spotify: "<:spotify:1259387939025191003>",
    search: "<:search:1259067310811906129>",
    track: "<:nmusic:1259389298810159156>",
  },

  //commands/music/skip
  skip: {
    yes: "<:tick_icon:1259061910473670730>",
    no: "<:nwrong:1259057991429390377>",
  },

  //commands/music/stop
  stop: {
    yes: "<:tick_icon:1259061910473670730>",
  },

  //commands/music/volume
  volume: {
    bell: "<:volumeee2:1259388113990586439>",
    yes: "<:tick_icon:1259061910473670730>",
    no: "<:nwrong:1259057991429390377>",
  },

  /////////////////////////////////////////////////////

  //commands/owner/add
  add: {
    admin: "<:admin:1259062418710073365>",
    bell: "<:eg_notification:1259057639753646080>",
    no: "<:nwrong:1259057991429390377>",
    on: "<:nenable:1259058313417461823>",
    user: "<:users:1259062697685684254>",
    yes: "<:tick_icon:1259061910473670730>",
  },

  //commands/owner/backup
  backup: {
    cool: "<:uptime:1259057811028049940>",
    yes: "<:tick_icon:1259061910473670730>",
    no: "<:nwrong:1259057991429390377>",
  },

  //commands/owner/coin
  coin: {
    coin: "<:coin:1188384481736929301>",
    yes: "<:tick_icon:1259061910473670730>",
    no: "<:nwrong:1259057991429390377>",
  },

  //commands/owner/list
  list: {
    bell: "<:eg_notification:1259057639753646080>",
    no: "<:nwrong:1259057991429390377>",
    cool: "<:uptime:1259057811028049940>",
    user: "<:users:1259062697685684254>",
    list: "<:list:1259388310162374657>",
  },

  //commands/owner/panel
  panel: {
    cool: "<:uptime:1259057811028049940>",
  },

  //commands/owner/pi
  pi: {},

  //commands/owner/reload
  reload: {},

  //commands/owner/restart
  restart: {
    bell: "<:eg_notification:1259057639753646080>",
    cool: "<:uptime:1259057811028049940>",
    no: "<:nwrong:1259057991429390377>",
    yes: "<:tick_icon:1259061910473670730>",
  },

  //commands/owner/revoke
  revoke: {
    admin: "<:admin:1259062418710073365>",
    bell: "<:eg_notification:1259057639753646080>",
    no: "<:nwrong:1259057991429390377>",
    on: "<:nenable:1259058313417461823>",
    off: "<:ndisable:1259058170656067585>",
    user: "<:users:1259062697685684254>",
    yes: "<:tick_icon:1259061910473670730>",
  },

  /////////////////////////////////////////////////////

  //stat cmd (bcevl + global)
  cog: "<:nsetting:1259061754219204618>",
  free: "<:free:1259059236747481129>",
  user: "<:users:1259062697685684254>",

  //global
  point: "<a:reddot_:1259061050935083008>",
  king: "<:owner:1259064731864399874>",
  bell: "<:eg_notification:1259057639753646080>",
  cool: "<:uptime:1259057811028049940>",
  warn: "<:warn:1259061550933606455>",
  yes: "<:tick_icon:1259061910473670730>",
  no: "<:nwrong:1259057991429390377>",
  helpline: "<:support:1189089913031897118>",
  message: "<:message:1259388525233569863>",
  free: "<:free:1259059236747481129>",
  new: "<:newMember:1259388694050242681>",
  admin: "<:admin:1259062418710073365>",
  rad: "<:radio:1259388822446280745>",
  diamond: "<:diamond:1191112574666809374>",
};