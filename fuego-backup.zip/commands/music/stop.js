/** @format
 *
 * Fuego By Painfuego
 * Version: 6.0.0-beta
 * © 2024 The Extremez
 */

module.exports = {
  name: "durdur",
  aliases: [],
  cooldown: "",
  category: "music",
  usage: "",
  description: "Çalma işlemine son ver",
  args: false,
  vote: false,
  new: false,
  admin: false,
  owner: false,
  botPerms: [],
  userPerms: [],
  player: true,
  queue: true,
  inVoiceChannel: true,
  sameVoiceChannel: true,
  execute: async (client, message, args, emoji) => {
    const player = await client.getPlayer(message.guild.id);

    player.queue.clear();
    player.data.delete("autoplay");
    player.loop = "none";
    player.playing = false;
    player.paused = false;
    await player.skip();
    await client.sleep(500);

    let emb = new client.embed().desc(
      ` **Stopped and destroyed the player**`,
    );
    message.reply({ embeds: [emb] }).catch(() => {});
  },
};
