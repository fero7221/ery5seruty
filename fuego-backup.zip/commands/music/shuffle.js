/** @format
 *
 * Fuego By Painfuego
 * Version: 6.0.0-beta
 * © 2024 The Extremez
 */

module.exports = {
  name: "karıştır",
  aliases: ["sh"],
  cooldown: "",
  category: "music",
  usage: "",
  description: "Kuyruğu karıştı",
  args: false,
  vote: false,
  new: false,
  admin: false,
  owner: false,
  botPerms: [],
  userPerms: [],
  player: true,
  queue: true,
  inVoiceChannel: true,
  sameVoiceChannel: true,
  execute: async (client, message, args, emoji) => {
    const player = await client.getPlayer(message.guild.id);

    let emb = new client.embed().desc(`${emoji.yes} **Shuffled the queue**`);
    await player.queue.shuffle();
    await message
      .reply({ embeds: [emb] })
      .then(async () => {
        await client.commands
          .get("queue")
          .execute(client, message, args, client.emoji.queue);
      })
      .catch(() => {});
  },
};
